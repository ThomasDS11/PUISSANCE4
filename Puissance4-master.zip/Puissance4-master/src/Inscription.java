
public class Inscription {
	
}
